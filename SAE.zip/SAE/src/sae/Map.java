/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sae;
import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.util.Scanner;
/**
 *
 * @author p2103642
 */
public class Map {
    Map(){
        
    }
public void loadMap(String filename){
    String res_file = "";
    try{
        File fileMap = new File(filename);
        Scanner fileReader = new Scanner(fileMap);
        while (fileReader.hasNextLine()){
            String data = fileReader.nextLine();
            res_file += data;
            //System.out.println(data);
        }
        fileReader.close();
        this.stringMap(res_file);
        
        
    } catch (FileNotFoundException e){
        System.out.println("Fichier introuvable");
        
    }
    
}
public void stringMap(String data){
    String[] villeListe;
    String villeInfo;
    String[] villeVoisine;
    
    villeListe = data.split(";;");
    for(int i=0; i<villeListe.length;i++){
        villeInfo = villeListe[i].substring(0,villeListe[i].indexOf(":"));
        villeVoisine = villeListe[i].substring(villeListe[i].indexOf(":")+1,villeListe[i].length()).split(";");
        System.out.println(villeListe[i]);
        System.out.println("Nom ville : "+villeInfo);

        for(int z=0; z<villeVoisine.length ;z++){
            System.out.println("Nom ville connecté : "+villeVoisine[z]);
            
        }
        
        
    }
    
   
    System.out.println(data);
    System.out.println(data.indexOf(";;"));
    System.out.println(data.indexOf(";;;"));
    
    
}
    
}
